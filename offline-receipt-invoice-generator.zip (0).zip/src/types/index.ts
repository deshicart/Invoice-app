export interface BusinessInfo {
  logo: string;
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface CustomerInfo {
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface Product {
  id: string;
  name: string;
  variation: string;
  deliveryType: 'standard' | 'express' | 'pickup' | 'digital';
  quantity: number;
  unitPrice: number;
  tax: number;
}

export interface InvoiceInfo {
  title: string;
  orderId: string;
  orderDate: string;
  prefix: string;
  autoId: boolean;
}

export interface PricingSummary {
  subtotal: number;
  shipping: number;
  totalTax: number;
  discount: number;
  grandTotal: number;
}

export interface PaymentInfo {
  method: 'cash' | 'card' | 'bank' | 'mobile' | 'other';
  status: 'paid' | 'pending' | 'partial' | 'overdue';
}

export interface Receipt {
  id: string;
  createdAt: string;
  updatedAt: string;
  business: BusinessInfo;
  customer: CustomerInfo;
  invoice: InvoiceInfo;
  products: Product[];
  shipping: number;
  discount: number;
  payment: PaymentInfo;
  notes: string;
  terms: string;
  signature: string;
  currency: string;
  dateFormat: string;
  style: 1 | 2 | 3;
  isDraft: boolean;
  isTemplate: boolean;
  templateName?: string;
}

export type ReceiptStyle = 1 | 2 | 3;
