import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import {
  FileText, Plus, Trash2, Download, Printer, Save,
  Building2, User, Package, CreditCard,
  Copy, FileCheck, Clock, Layout, LayoutGrid, Receipt as ReceiptIcon,
  X, Edit3, Image, FileSignature, StickyNote,
  Menu, History, Bookmark
} from 'lucide-react';
import { Receipt, Product, ReceiptStyle, PaymentInfo } from './types';
import { storage } from './utils/storage';
import { generateQRCode, generateBarcode } from './utils/qrcode';
import { cn } from './utils/cn';

// Receipt Preview Components
const ReceiptStyle1 = ({ receipt, qrCode, barcode }: { receipt: Receipt; qrCode: string; barcode: string }) => {
  const subtotal = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice), 0);
  const totalTax = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice * p.tax / 100), 0);
  const grandTotal = subtotal + totalTax + receipt.shipping - receipt.discount;

  return (
    <div className="bg-white p-8 min-h-[297mm] w-full max-w-[210mm] mx-auto shadow-lg" style={{ fontFamily: "'Poppins', 'Hind Siliguri', sans-serif" }}>
      {/* Header */}
      <div className="flex justify-between items-start border-b-2 border-indigo-600 pb-6 mb-6">
        <div className="flex items-center gap-4">
          {receipt.business.logo ? (
            <img src={receipt.business.logo} alt="Logo" className="w-16 h-16 object-contain rounded-lg" />
          ) : (
            <div className="w-16 h-16 bg-indigo-100 rounded-lg flex items-center justify-center">
              <Building2 className="w-8 h-8 text-indigo-600" />
            </div>
          )}
          <div>
            <h1 className="text-2xl font-bold text-gray-800">{receipt.business.name || 'Your Business'}</h1>
            <p className="text-sm text-gray-500">{receipt.business.email}</p>
            <p className="text-sm text-gray-500">{receipt.business.phone}</p>
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-3xl font-bold text-indigo-600">{receipt.invoice.title || 'INVOICE'}</h2>
          <p className="text-sm text-gray-600 mt-2">
            <span className="font-medium">Invoice #:</span> {receipt.invoice.prefix}{receipt.invoice.orderId}
          </p>
          <p className="text-sm text-gray-600">
            <span className="font-medium">Date:</span> {receipt.invoice.orderDate}
          </p>
          <div className={cn(
            "inline-block px-3 py-1 rounded-full text-xs font-medium mt-2",
            receipt.payment.status === 'paid' && "bg-green-100 text-green-700",
            receipt.payment.status === 'pending' && "bg-yellow-100 text-yellow-700",
            receipt.payment.status === 'partial' && "bg-blue-100 text-blue-700",
            receipt.payment.status === 'overdue' && "bg-red-100 text-red-700",
          )}>
            {receipt.payment.status.toUpperCase()}
          </div>
        </div>
      </div>

      {/* Business & Customer Info */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase mb-2">From</h3>
          <p className="font-medium text-gray-800">{receipt.business.name}</p>
          <p className="text-sm text-gray-600">{receipt.business.address}</p>
          <p className="text-sm text-gray-600">{receipt.business.email}</p>
          <p className="text-sm text-gray-600">{receipt.business.phone}</p>
        </div>
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase mb-2">Bill To</h3>
          <p className="font-medium text-gray-800">{receipt.customer.name || 'Customer Name'}</p>
          <p className="text-sm text-gray-600">{receipt.customer.address}</p>
          <p className="text-sm text-gray-600">{receipt.customer.email}</p>
          <p className="text-sm text-gray-600">{receipt.customer.phone}</p>
        </div>
      </div>

      {/* Products Table */}
      <table className="w-full mb-8">
        <thead>
          <tr className="bg-indigo-600 text-white">
            <th className="text-left py-3 px-4 font-medium">Item</th>
            <th className="text-left py-3 px-4 font-medium">Variation</th>
            <th className="text-center py-3 px-4 font-medium">Qty</th>
            <th className="text-right py-3 px-4 font-medium">Price</th>
            <th className="text-right py-3 px-4 font-medium">Tax</th>
            <th className="text-right py-3 px-4 font-medium">Total</th>
          </tr>
        </thead>
        <tbody>
          {receipt.products.map((product, index) => (
            <tr key={product.id} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
              <td className="py-3 px-4 text-gray-800">{product.name}</td>
              <td className="py-3 px-4 text-gray-600">{product.variation || '-'}</td>
              <td className="py-3 px-4 text-center text-gray-800">{product.quantity}</td>
              <td className="py-3 px-4 text-right text-gray-800">{receipt.currency}{product.unitPrice.toFixed(2)}</td>
              <td className="py-3 px-4 text-right text-gray-600">{product.tax}%</td>
              <td className="py-3 px-4 text-right font-medium text-gray-800">
                {receipt.currency}{(product.quantity * product.unitPrice * (1 + product.tax / 100)).toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Summary */}
      <div className="flex justify-end mb-8">
        <div className="w-72">
          <div className="flex justify-between py-2 border-b">
            <span className="text-gray-600">Subtotal</span>
            <span className="font-medium">{receipt.currency}{subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between py-2 border-b">
            <span className="text-gray-600">Tax</span>
            <span className="font-medium">{receipt.currency}{totalTax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between py-2 border-b">
            <span className="text-gray-600">Shipping</span>
            <span className="font-medium">{receipt.currency}{receipt.shipping.toFixed(2)}</span>
          </div>
          {receipt.discount > 0 && (
            <div className="flex justify-between py-2 border-b text-green-600">
              <span>Discount</span>
              <span className="font-medium">-{receipt.currency}{receipt.discount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between py-3 bg-indigo-600 text-white px-4 -mx-0 mt-2 rounded">
            <span className="font-bold">Grand Total</span>
            <span className="font-bold text-xl">{receipt.currency}{grandTotal.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Payment Info */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase mb-2">Payment Method</h3>
          <p className="text-gray-800 capitalize">{receipt.payment.method}</p>
        </div>
        {qrCode && (
          <div className="flex justify-end">
            <img src={qrCode} alt="QR Code" className="w-24 h-24" />
          </div>
        )}
      </div>

      {/* Notes & Terms */}
      {(receipt.notes || receipt.terms) && (
        <div className="border-t pt-6 mb-6">
          {receipt.notes && (
            <div className="mb-4">
              <h3 className="text-sm font-semibold text-gray-400 uppercase mb-2">Notes</h3>
              <p className="text-sm text-gray-600">{receipt.notes}</p>
            </div>
          )}
          {receipt.terms && (
            <div>
              <h3 className="text-sm font-semibold text-gray-400 uppercase mb-2">Terms & Conditions</h3>
              <p className="text-sm text-gray-600">{receipt.terms}</p>
            </div>
          )}
        </div>
      )}

      {/* Signature & Barcode */}
      <div className="flex justify-between items-end pt-6 border-t">
        {receipt.signature ? (
          <div>
            <img src={receipt.signature} alt="Signature" className="h-16 mb-2" />
            <div className="border-t border-gray-300 pt-2">
              <p className="text-sm text-gray-600">Authorized Signature</p>
            </div>
          </div>
        ) : (
          <div className="w-48 border-t-2 border-gray-300 pt-2">
            <p className="text-sm text-gray-600">Authorized Signature</p>
          </div>
        )}
        {barcode && <img src={barcode} alt="Barcode" className="h-16" />}
      </div>
    </div>
  );
};

const ReceiptStyle2 = ({ receipt, qrCode }: { receipt: Receipt; qrCode: string }) => {
  const subtotal = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice), 0);
  const totalTax = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice * p.tax / 100), 0);
  const grandTotal = subtotal + totalTax + receipt.shipping - receipt.discount;

  return (
    <div className="bg-gradient-to-br from-slate-50 to-white p-6 min-h-[297mm] w-full max-w-[210mm] mx-auto" style={{ fontFamily: "'Poppins', 'Hind Siliguri', sans-serif" }}>
      {/* Modern Card Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-6 text-white mb-6 shadow-xl">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            {receipt.business.logo ? (
              <img src={receipt.business.logo} alt="Logo" className="w-14 h-14 object-contain rounded-xl bg-white p-1" />
            ) : (
              <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
                <Building2 className="w-7 h-7" />
              </div>
            )}
            <div>
              <h1 className="text-xl font-bold">{receipt.business.name || 'Your Business'}</h1>
              <p className="text-sm opacity-80">{receipt.business.email}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold">{receipt.invoice.title || 'INVOICE'}</p>
            <p className="text-sm opacity-80">#{receipt.invoice.prefix}{receipt.invoice.orderId}</p>
          </div>
        </div>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-xl p-5 shadow-md border border-gray-100">
          <div className="flex items-center gap-2 mb-3">
            <User className="w-4 h-4 text-indigo-600" />
            <h3 className="text-xs font-semibold text-gray-400 uppercase">Customer</h3>
          </div>
          <p className="font-semibold text-gray-800">{receipt.customer.name || 'Customer Name'}</p>
          <p className="text-sm text-gray-500">{receipt.customer.phone}</p>
          <p className="text-sm text-gray-500">{receipt.customer.email}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-md border border-gray-100">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="w-4 h-4 text-indigo-600" />
            <h3 className="text-xs font-semibold text-gray-400 uppercase">Invoice Details</h3>
          </div>
          <p className="text-sm text-gray-600"><span className="font-medium">Date:</span> {receipt.invoice.orderDate}</p>
          <p className="text-sm text-gray-600"><span className="font-medium">Payment:</span> {receipt.payment.method}</p>
          <span className={cn(
            "inline-block px-2 py-0.5 rounded-full text-xs font-medium mt-1",
            receipt.payment.status === 'paid' && "bg-green-100 text-green-700",
            receipt.payment.status === 'pending' && "bg-yellow-100 text-yellow-700",
            receipt.payment.status === 'partial' && "bg-blue-100 text-blue-700",
            receipt.payment.status === 'overdue' && "bg-red-100 text-red-700",
          )}>
            {receipt.payment.status.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Products */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden mb-6">
        <div className="p-4 border-b bg-gray-50">
          <h3 className="font-semibold text-gray-800 flex items-center gap-2">
            <Package className="w-4 h-4 text-indigo-600" />
            Items
          </h3>
        </div>
        <div className="divide-y">
          {receipt.products.map((product) => (
            <div key={product.id} className="p-4 flex justify-between items-center">
              <div>
                <p className="font-medium text-gray-800">{product.name}</p>
                <p className="text-sm text-gray-500">{product.variation} • Qty: {product.quantity}</p>
              </div>
              <p className="font-semibold text-gray-800">
                {receipt.currency}{(product.quantity * product.unitPrice * (1 + product.tax / 100)).toFixed(2)}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Summary Card */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-5 mb-6">
        <div className="space-y-2">
          <div className="flex justify-between text-gray-600">
            <span>Subtotal</span>
            <span>{receipt.currency}{subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-gray-600">
            <span>Tax</span>
            <span>{receipt.currency}{totalTax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-gray-600">
            <span>Shipping</span>
            <span>{receipt.currency}{receipt.shipping.toFixed(2)}</span>
          </div>
          {receipt.discount > 0 && (
            <div className="flex justify-between text-green-600">
              <span>Discount</span>
              <span>-{receipt.currency}{receipt.discount.toFixed(2)}</span>
            </div>
          )}
          <div className="border-t pt-3 mt-3">
            <div className="flex justify-between">
              <span className="text-lg font-bold text-gray-800">Total</span>
              <span className="text-2xl font-bold text-indigo-600">{receipt.currency}{grandTotal.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer with QR */}
      <div className="flex justify-between items-end">
        <div className="text-sm text-gray-500">
          {receipt.notes && <p className="mb-2">{receipt.notes}</p>}
          <p>Thank you for your business!</p>
        </div>
        {qrCode && <img src={qrCode} alt="QR Code" className="w-20 h-20 rounded-lg" />}
      </div>
    </div>
  );
};

const ReceiptStyle3 = ({ receipt }: { receipt: Receipt }) => {
  const subtotal = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice), 0);
  const totalTax = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice * p.tax / 100), 0);
  const grandTotal = subtotal + totalTax + receipt.shipping - receipt.discount;

  return (
    <div className="bg-white p-4 w-80 mx-auto shadow-lg font-mono text-sm" style={{ fontFamily: "'Courier New', monospace" }}>
      {/* Thermal Header */}
      <div className="text-center border-b-2 border-dashed border-gray-400 pb-4 mb-4">
        {receipt.business.logo ? (
          <img src={receipt.business.logo} alt="Logo" className="w-16 h-16 mx-auto mb-2 object-contain" />
        ) : (
          <div className="w-16 h-16 mx-auto mb-2 bg-gray-100 rounded flex items-center justify-center">
            <Building2 className="w-8 h-8 text-gray-600" />
          </div>
        )}
        <h1 className="text-lg font-bold uppercase">{receipt.business.name || 'STORE NAME'}</h1>
        <p className="text-xs text-gray-600">{receipt.business.address}</p>
        <p className="text-xs text-gray-600">{receipt.business.phone}</p>
      </div>

      {/* Receipt Info */}
      <div className="border-b border-dashed border-gray-400 pb-3 mb-3">
        <div className="flex justify-between text-xs">
          <span>Receipt #:</span>
          <span>{receipt.invoice.prefix}{receipt.invoice.orderId}</span>
        </div>
        <div className="flex justify-between text-xs">
          <span>Date:</span>
          <span>{receipt.invoice.orderDate}</span>
        </div>
        <div className="flex justify-between text-xs">
          <span>Customer:</span>
          <span>{receipt.customer.name || 'Walk-in'}</span>
        </div>
      </div>

      {/* Items */}
      <div className="border-b border-dashed border-gray-400 pb-3 mb-3">
        <div className="text-xs font-bold mb-2 flex justify-between">
          <span>ITEM</span>
          <span>TOTAL</span>
        </div>
        {receipt.products.map((product) => (
          <div key={product.id} className="mb-2">
            <div className="flex justify-between text-xs">
              <span className="truncate max-w-[180px]">{product.name}</span>
              <span>{receipt.currency}{(product.quantity * product.unitPrice).toFixed(2)}</span>
            </div>
            <div className="text-xs text-gray-500 pl-2">
              {product.quantity} x {receipt.currency}{product.unitPrice.toFixed(2)}
              {product.tax > 0 && ` (+${product.tax}% tax)`}
            </div>
          </div>
        ))}
      </div>

      {/* Totals */}
      <div className="border-b-2 border-dashed border-gray-400 pb-3 mb-3">
        <div className="flex justify-between text-xs">
          <span>Subtotal:</span>
          <span>{receipt.currency}{subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-xs">
          <span>Tax:</span>
          <span>{receipt.currency}{totalTax.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-xs">
          <span>Shipping:</span>
          <span>{receipt.currency}{receipt.shipping.toFixed(2)}</span>
        </div>
        {receipt.discount > 0 && (
          <div className="flex justify-between text-xs">
            <span>Discount:</span>
            <span>-{receipt.currency}{receipt.discount.toFixed(2)}</span>
          </div>
        )}
        <div className="flex justify-between text-base font-bold mt-2 pt-2 border-t border-gray-300">
          <span>TOTAL:</span>
          <span>{receipt.currency}{grandTotal.toFixed(2)}</span>
        </div>
      </div>

      {/* Payment */}
      <div className="text-center text-xs mb-3">
        <p>Payment: {receipt.payment.method.toUpperCase()}</p>
        <p>Status: {receipt.payment.status.toUpperCase()}</p>
      </div>

      {/* Footer */}
      <div className="text-center border-t border-dashed border-gray-400 pt-3">
        <p className="text-xs text-gray-600 mb-2">{receipt.notes || 'Thank you for shopping!'}</p>
        <p className="text-xs">********************************</p>
        <p className="text-xs font-bold mt-2">CUSTOMER COPY</p>
      </div>
    </div>
  );
};

// PDF generation is handled directly in downloadPDF with inline HTML

// Main App Component
export function App() {
  const [activeTab, setActiveTab] = useState<'create' | 'history' | 'templates'>('create');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [receipt, setReceipt] = useState<Receipt>(() => createNewReceipt());
  const [qrCode, setQrCode] = useState('');
  const [barcode, setBarcode] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [drafts, setDrafts] = useState<Receipt[]>([]);
  const [templates, setTemplates] = useState<Receipt[]>([]);
  const [templateName, setTemplateName] = useState('');
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  function createNewReceipt(): Receipt {
    const savedBusiness = storage.getBusinessInfo();
    const settings = storage.getSettings();
    return {
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      business: savedBusiness || {
        logo: '',
        name: '',
        email: '',
        phone: '',
        address: '',
      },
      customer: {
        name: '',
        email: '',
        phone: '',
        address: '',
      },
      invoice: {
        title: 'INVOICE',
        orderId: Math.random().toString(36).substring(2, 8).toUpperCase(),
        orderDate: new Date().toLocaleDateString(),
        prefix: 'INV-',
        autoId: true,
      },
      products: [
        { id: uuidv4(), name: '', variation: '', deliveryType: 'standard', quantity: 1, unitPrice: 0, tax: 0 },
      ],
      shipping: 0,
      discount: 0,
      payment: {
        method: 'cash',
        status: 'pending',
      },
      notes: '',
      terms: '',
      signature: '',
      currency: settings.currency || '৳',
      dateFormat: settings.dateFormat || 'DD/MM/YYYY',
      style: 1,
      isDraft: false,
      isTemplate: false,
    };
  }

  useEffect(() => {
    setReceipts(storage.getReceipts());
    setDrafts(storage.getDrafts());
    setTemplates(storage.getTemplates());
  }, []);

  useEffect(() => {
    const generateCodes = async () => {
      const invoiceData = `Invoice: ${receipt.invoice.prefix}${receipt.invoice.orderId}\nDate: ${receipt.invoice.orderDate}\nTotal: ${receipt.currency}${calculateGrandTotal()}`;
      const qr = await generateQRCode(invoiceData);
      setQrCode(qr);
      const bc = generateBarcode(receipt.invoice.orderId);
      setBarcode(bc);
    };
    generateCodes();
  }, [receipt.invoice.orderId, receipt.invoice.prefix]);

  const calculateSubtotal = useCallback(() => {
    return receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice), 0);
  }, [receipt.products]);

  const calculateTotalTax = useCallback(() => {
    return receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice * p.tax / 100), 0);
  }, [receipt.products]);

  const calculateGrandTotal = useCallback(() => {
    return calculateSubtotal() + calculateTotalTax() + receipt.shipping - receipt.discount;
  }, [calculateSubtotal, calculateTotalTax, receipt.shipping, receipt.discount]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReceipt(prev => ({
          ...prev,
          business: { ...prev.business, logo: reader.result as string }
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReceipt(prev => ({ ...prev, signature: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const addProduct = () => {
    setReceipt(prev => ({
      ...prev,
      products: [
        ...prev.products,
        { id: uuidv4(), name: '', variation: '', deliveryType: 'standard', quantity: 1, unitPrice: 0, tax: 0 },
      ],
    }));
  };

  const removeProduct = (id: string) => {
    if (receipt.products.length > 1) {
      setReceipt(prev => ({
        ...prev,
        products: prev.products.filter(p => p.id !== id),
      }));
    }
  };

  const updateProduct = (id: string, field: keyof Product, value: string | number) => {
    setReceipt(prev => ({
      ...prev,
      products: prev.products.map(p =>
        p.id === id ? { ...p, [field]: value } : p
      ),
    }));
  };

  const saveDraft = () => {
    const draft = { ...receipt, isDraft: true, updatedAt: new Date().toISOString() };
    storage.saveDraft(draft);
    setDrafts(storage.getDrafts());
    alert('Draft saved successfully!');
  };

  const saveAsTemplate = () => {
    if (!templateName.trim()) {
      alert('Please enter a template name');
      return;
    }
    const template = { 
      ...receipt, 
      isTemplate: true, 
      templateName: templateName.trim(),
      id: uuidv4(),
      updatedAt: new Date().toISOString() 
    };
    storage.saveTemplate(template);
    setTemplates(storage.getTemplates());
    setShowTemplateModal(false);
    setTemplateName('');
    alert('Template saved successfully!');
  };

  const loadReceipt = (r: Receipt) => {
    setReceipt({ ...r, id: uuidv4(), createdAt: new Date().toISOString() });
    setActiveTab('create');
    setSidebarOpen(false);
  };

  const saveReceipt = () => {
    const saved = { ...receipt, isDraft: false, updatedAt: new Date().toISOString() };
    storage.saveReceipt(saved);
    storage.saveBusinessInfo(receipt.business);
    setReceipts(storage.getReceipts());
    alert('Receipt saved successfully!');
  };

  const downloadPDF = async () => {
    setIsGenerating(true);
    
    try {
      // Create a fresh container with the receipt content
      const printContainer = document.createElement('div');
      printContainer.id = 'print-pdf-container';
      printContainer.style.cssText = `
        position: fixed;
        left: 0;
        top: 0;
        width: ${receipt.style === 3 ? '320px' : '794px'};
        background-color: white;
        z-index: 99999;
        pointer-events: none;
      `;
      
      // Build the receipt HTML directly
      const subtotal = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice), 0);
      const totalTax = receipt.products.reduce((sum, p) => sum + (p.quantity * p.unitPrice * p.tax / 100), 0);
      const grandTotal = subtotal + totalTax + receipt.shipping - receipt.discount;
      
      const statusColors: Record<string, string> = {
        paid: 'background-color: #dcfce7; color: #15803d;',
        pending: 'background-color: #fef9c3; color: #a16207;',
        partial: 'background-color: #dbeafe; color: #1d4ed8;',
        overdue: 'background-color: #fee2e2; color: #dc2626;'
      };
      
      if (receipt.style === 1) {
        printContainer.innerHTML = `
          <div style="background: white; padding: 32px; font-family: 'Poppins', 'Hind Siliguri', sans-serif; min-height: 1123px; width: 794px;">
            <!-- Header -->
            <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #4f46e5; padding-bottom: 24px; margin-bottom: 24px;">
              <div style="display: flex; align-items: center; gap: 16px;">
                ${receipt.business.logo ? `<img src="${receipt.business.logo}" alt="Logo" style="width: 64px; height: 64px; object-fit: contain; border-radius: 8px;" />` : `<div style="width: 64px; height: 64px; background: #e0e7ff; border-radius: 8px; display: flex; align-items: center; justify-content: center;"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#4f46e5" stroke-width="2"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/></svg></div>`}
                <div>
                  <h1 style="font-size: 24px; font-weight: bold; color: #1f2937; margin: 0;">${receipt.business.name || 'Your Business'}</h1>
                  <p style="font-size: 14px; color: #6b7280; margin: 4px 0;">${receipt.business.email}</p>
                  <p style="font-size: 14px; color: #6b7280; margin: 0;">${receipt.business.phone}</p>
                </div>
              </div>
              <div style="text-align: right;">
                <h2 style="font-size: 32px; font-weight: bold; color: #4f46e5; margin: 0;">${receipt.invoice.title || 'INVOICE'}</h2>
                <p style="font-size: 14px; color: #4b5563; margin: 8px 0;"><span style="font-weight: 500;">Invoice #:</span> ${receipt.invoice.prefix}${receipt.invoice.orderId}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0;"><span style="font-weight: 500;">Date:</span> ${receipt.invoice.orderDate}</p>
                <span style="display: inline-block; padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: 500; margin-top: 8px; ${statusColors[receipt.payment.status]}">${receipt.payment.status.toUpperCase()}</span>
              </div>
            </div>
            
            <!-- Business & Customer -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 32px; margin-bottom: 32px;">
              <div>
                <h3 style="font-size: 12px; font-weight: 600; color: #9ca3af; text-transform: uppercase; margin: 0 0 8px;">From</h3>
                <p style="font-weight: 500; color: #1f2937; margin: 0 0 4px;">${receipt.business.name}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0 0 4px;">${receipt.business.address}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0 0 4px;">${receipt.business.email}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0;">${receipt.business.phone}</p>
              </div>
              <div>
                <h3 style="font-size: 12px; font-weight: 600; color: #9ca3af; text-transform: uppercase; margin: 0 0 8px;">Bill To</h3>
                <p style="font-weight: 500; color: #1f2937; margin: 0 0 4px;">${receipt.customer.name || 'Customer Name'}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0 0 4px;">${receipt.customer.address}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0 0 4px;">${receipt.customer.email}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0;">${receipt.customer.phone}</p>
              </div>
            </div>
            
            <!-- Products Table -->
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 32px;">
              <thead>
                <tr style="background: #4f46e5; color: white;">
                  <th style="text-align: left; padding: 12px 16px; font-weight: 500;">Item</th>
                  <th style="text-align: left; padding: 12px 16px; font-weight: 500;">Variation</th>
                  <th style="text-align: center; padding: 12px 16px; font-weight: 500;">Qty</th>
                  <th style="text-align: right; padding: 12px 16px; font-weight: 500;">Price</th>
                  <th style="text-align: right; padding: 12px 16px; font-weight: 500;">Tax</th>
                  <th style="text-align: right; padding: 12px 16px; font-weight: 500;">Total</th>
                </tr>
              </thead>
              <tbody>
                ${receipt.products.map((p, i) => `
                  <tr style="background: ${i % 2 === 0 ? '#f9fafb' : 'white'};">
                    <td style="padding: 12px 16px; color: #1f2937;">${p.name || 'Item'}</td>
                    <td style="padding: 12px 16px; color: #4b5563;">${p.variation || '-'}</td>
                    <td style="padding: 12px 16px; text-align: center; color: #1f2937;">${p.quantity}</td>
                    <td style="padding: 12px 16px; text-align: right; color: #1f2937;">${receipt.currency}${p.unitPrice.toFixed(2)}</td>
                    <td style="padding: 12px 16px; text-align: right; color: #4b5563;">${p.tax}%</td>
                    <td style="padding: 12px 16px; text-align: right; font-weight: 500; color: #1f2937;">${receipt.currency}${(p.quantity * p.unitPrice * (1 + p.tax / 100)).toFixed(2)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            
            <!-- Summary -->
            <div style="display: flex; justify-content: flex-end; margin-bottom: 32px;">
              <div style="width: 288px;">
                <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e5e7eb;">
                  <span style="color: #4b5563;">Subtotal</span>
                  <span style="font-weight: 500;">${receipt.currency}${subtotal.toFixed(2)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e5e7eb;">
                  <span style="color: #4b5563;">Tax</span>
                  <span style="font-weight: 500;">${receipt.currency}${totalTax.toFixed(2)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e5e7eb;">
                  <span style="color: #4b5563;">Shipping</span>
                  <span style="font-weight: 500;">${receipt.currency}${receipt.shipping.toFixed(2)}</span>
                </div>
                ${receipt.discount > 0 ? `
                  <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e5e7eb; color: #16a34a;">
                    <span>Discount</span>
                    <span style="font-weight: 500;">-${receipt.currency}${receipt.discount.toFixed(2)}</span>
                  </div>
                ` : ''}
                <div style="display: flex; justify-content: space-between; padding: 12px 16px; background: #4f46e5; color: white; border-radius: 8px; margin-top: 8px;">
                  <span style="font-weight: bold;">Grand Total</span>
                  <span style="font-weight: bold; font-size: 20px;">${receipt.currency}${grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <!-- Payment & QR -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 32px; margin-bottom: 32px;">
              <div>
                <h3 style="font-size: 12px; font-weight: 600; color: #9ca3af; text-transform: uppercase; margin: 0 0 8px;">Payment Method</h3>
                <p style="color: #1f2937; text-transform: capitalize; margin: 0;">${receipt.payment.method}</p>
              </div>
              ${qrCode ? `<div style="display: flex; justify-content: flex-end;"><img src="${qrCode}" alt="QR" style="width: 96px; height: 96px;" /></div>` : ''}
            </div>
            
            <!-- Notes -->
            ${receipt.notes || receipt.terms ? `
              <div style="border-top: 1px solid #e5e7eb; padding-top: 24px; margin-bottom: 24px;">
                ${receipt.notes ? `<div style="margin-bottom: 16px;"><h3 style="font-size: 12px; font-weight: 600; color: #9ca3af; text-transform: uppercase; margin: 0 0 8px;">Notes</h3><p style="font-size: 14px; color: #4b5563; margin: 0;">${receipt.notes}</p></div>` : ''}
                ${receipt.terms ? `<div><h3 style="font-size: 12px; font-weight: 600; color: #9ca3af; text-transform: uppercase; margin: 0 0 8px;">Terms & Conditions</h3><p style="font-size: 14px; color: #4b5563; margin: 0;">${receipt.terms}</p></div>` : ''}
              </div>
            ` : ''}
            
            <!-- Signature & Barcode -->
            <div style="display: flex; justify-content: space-between; align-items: flex-end; padding-top: 24px; border-top: 1px solid #e5e7eb;">
              ${receipt.signature ? `
                <div>
                  <img src="${receipt.signature}" alt="Signature" style="height: 64px; margin-bottom: 8px;" />
                  <div style="border-top: 1px solid #d1d5db; padding-top: 8px;">
                    <p style="font-size: 14px; color: #4b5563; margin: 0;">Authorized Signature</p>
                  </div>
                </div>
              ` : `
                <div style="width: 192px; border-top: 2px solid #d1d5db; padding-top: 8px;">
                  <p style="font-size: 14px; color: #4b5563; margin: 0;">Authorized Signature</p>
                </div>
              `}
              ${barcode ? `<img src="${barcode}" alt="Barcode" style="height: 64px;" />` : ''}
            </div>
          </div>
        `;
      } else if (receipt.style === 2) {
        printContainer.innerHTML = `
          <div style="background: linear-gradient(to bottom right, #f8fafc, white); padding: 24px; font-family: 'Poppins', 'Hind Siliguri', sans-serif; min-height: 1123px; width: 794px;">
            <!-- Modern Header -->
            <div style="background: linear-gradient(to right, #4f46e5, #9333ea); border-radius: 16px; padding: 24px; color: white; margin-bottom: 24px; box-shadow: 0 10px 25px rgba(79, 70, 229, 0.3);">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 16px;">
                  ${receipt.business.logo ? `<img src="${receipt.business.logo}" alt="Logo" style="width: 56px; height: 56px; object-fit: contain; border-radius: 12px; background: white; padding: 4px;" />` : `<div style="width: 56px; height: 56px; background: rgba(255,255,255,0.2); border-radius: 12px; display: flex; align-items: center; justify-content: center;"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/></svg></div>`}
                  <div>
                    <h1 style="font-size: 20px; font-weight: bold; margin: 0;">${receipt.business.name || 'Your Business'}</h1>
                    <p style="font-size: 14px; opacity: 0.8; margin: 4px 0 0;">${receipt.business.email}</p>
                  </div>
                </div>
                <div style="text-align: right;">
                  <p style="font-size: 28px; font-weight: bold; margin: 0;">${receipt.invoice.title || 'INVOICE'}</p>
                  <p style="font-size: 14px; opacity: 0.8; margin: 4px 0 0;">#${receipt.invoice.prefix}${receipt.invoice.orderId}</p>
                </div>
              </div>
            </div>
            
            <!-- Info Cards -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px;">
              <div style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #f3f4f6;">
                <h3 style="font-size: 11px; font-weight: 600; color: #9ca3af; text-transform: uppercase; margin: 0 0 12px;">Customer</h3>
                <p style="font-weight: 600; color: #1f2937; margin: 0 0 4px;">${receipt.customer.name || 'Customer Name'}</p>
                <p style="font-size: 14px; color: #6b7280; margin: 0 0 4px;">${receipt.customer.phone}</p>
                <p style="font-size: 14px; color: #6b7280; margin: 0;">${receipt.customer.email}</p>
              </div>
              <div style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #f3f4f6;">
                <h3 style="font-size: 11px; font-weight: 600; color: #9ca3af; text-transform: uppercase; margin: 0 0 12px;">Invoice Details</h3>
                <p style="font-size: 14px; color: #4b5563; margin: 0 0 4px;"><span style="font-weight: 500;">Date:</span> ${receipt.invoice.orderDate}</p>
                <p style="font-size: 14px; color: #4b5563; margin: 0 0 4px;"><span style="font-weight: 500;">Payment:</span> ${receipt.payment.method}</p>
                <span style="display: inline-block; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 500; ${statusColors[receipt.payment.status]}">${receipt.payment.status.toUpperCase()}</span>
              </div>
            </div>
            
            <!-- Products Card -->
            <div style="background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #f3f4f6; overflow: hidden; margin-bottom: 24px;">
              <div style="padding: 16px; border-bottom: 1px solid #f3f4f6; background: #f9fafb;">
                <h3 style="font-weight: 600; color: #1f2937; margin: 0;">Items</h3>
              </div>
              ${receipt.products.map(p => `
                <div style="padding: 16px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f3f4f6;">
                  <div>
                    <p style="font-weight: 500; color: #1f2937; margin: 0 0 4px;">${p.name || 'Item'}</p>
                    <p style="font-size: 14px; color: #6b7280; margin: 0;">${p.variation || '-'} • Qty: ${p.quantity}</p>
                  </div>
                  <p style="font-weight: 600; color: #1f2937; margin: 0;">${receipt.currency}${(p.quantity * p.unitPrice * (1 + p.tax / 100)).toFixed(2)}</p>
                </div>
              `).join('')}
            </div>
            
            <!-- Summary Card -->
            <div style="background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #f3f4f6; padding: 20px; margin-bottom: 24px;">
              <div style="display: flex; justify-content: space-between; color: #4b5563; margin-bottom: 8px;">
                <span>Subtotal</span>
                <span>${receipt.currency}${subtotal.toFixed(2)}</span>
              </div>
              <div style="display: flex; justify-content: space-between; color: #4b5563; margin-bottom: 8px;">
                <span>Tax</span>
                <span>${receipt.currency}${totalTax.toFixed(2)}</span>
              </div>
              <div style="display: flex; justify-content: space-between; color: #4b5563; margin-bottom: 8px;">
                <span>Shipping</span>
                <span>${receipt.currency}${receipt.shipping.toFixed(2)}</span>
              </div>
              ${receipt.discount > 0 ? `
                <div style="display: flex; justify-content: space-between; color: #16a34a; margin-bottom: 8px;">
                  <span>Discount</span>
                  <span>-${receipt.currency}${receipt.discount.toFixed(2)}</span>
                </div>
              ` : ''}
              <div style="border-top: 1px solid #e5e7eb; padding-top: 12px; margin-top: 12px;">
                <div style="display: flex; justify-content: space-between;">
                  <span style="font-size: 18px; font-weight: bold; color: #1f2937;">Total</span>
                  <span style="font-size: 24px; font-weight: bold; color: #4f46e5;">${receipt.currency}${grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <!-- Footer -->
            <div style="display: flex; justify-content: space-between; align-items: flex-end;">
              <div style="font-size: 14px; color: #6b7280;">
                ${receipt.notes ? `<p style="margin: 0 0 8px;">${receipt.notes}</p>` : ''}
                <p style="margin: 0;">Thank you for your business!</p>
              </div>
              ${qrCode ? `<img src="${qrCode}" alt="QR" style="width: 80px; height: 80px; border-radius: 8px;" />` : ''}
            </div>
          </div>
        `;
      } else {
        // Thermal style
        printContainer.innerHTML = `
          <div style="background: white; padding: 16px; width: 320px; font-family: 'Courier New', monospace; font-size: 14px;">
            <!-- Header -->
            <div style="text-align: center; border-bottom: 2px dashed #9ca3af; padding-bottom: 16px; margin-bottom: 16px;">
              ${receipt.business.logo ? `<img src="${receipt.business.logo}" alt="Logo" style="width: 64px; height: 64px; margin: 0 auto 8px; display: block; object-fit: contain;" />` : ''}
              <h1 style="font-size: 18px; font-weight: bold; text-transform: uppercase; margin: 0;">${receipt.business.name || 'STORE NAME'}</h1>
              <p style="font-size: 12px; color: #4b5563; margin: 4px 0 0;">${receipt.business.address}</p>
              <p style="font-size: 12px; color: #4b5563; margin: 4px 0 0;">${receipt.business.phone}</p>
            </div>
            
            <!-- Receipt Info -->
            <div style="border-bottom: 1px dashed #9ca3af; padding-bottom: 12px; margin-bottom: 12px;">
              <div style="display: flex; justify-content: space-between; font-size: 12px;">
                <span>Receipt #:</span>
                <span>${receipt.invoice.prefix}${receipt.invoice.orderId}</span>
              </div>
              <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 4px;">
                <span>Date:</span>
                <span>${receipt.invoice.orderDate}</span>
              </div>
              <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 4px;">
                <span>Customer:</span>
                <span>${receipt.customer.name || 'Walk-in'}</span>
              </div>
            </div>
            
            <!-- Items -->
            <div style="border-bottom: 1px dashed #9ca3af; padding-bottom: 12px; margin-bottom: 12px;">
              <div style="font-size: 12px; font-weight: bold; margin-bottom: 8px; display: flex; justify-content: space-between;">
                <span>ITEM</span>
                <span>TOTAL</span>
              </div>
              ${receipt.products.map(p => `
                <div style="margin-bottom: 8px;">
                  <div style="display: flex; justify-content: space-between; font-size: 12px;">
                    <span style="max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${p.name || 'Item'}</span>
                    <span>${receipt.currency}${(p.quantity * p.unitPrice).toFixed(2)}</span>
                  </div>
                  <div style="font-size: 12px; color: #6b7280; padding-left: 8px;">
                    ${p.quantity} x ${receipt.currency}${p.unitPrice.toFixed(2)}${p.tax > 0 ? ` (+${p.tax}% tax)` : ''}
                  </div>
                </div>
              `).join('')}
            </div>
            
            <!-- Totals -->
            <div style="border-bottom: 2px dashed #9ca3af; padding-bottom: 12px; margin-bottom: 12px;">
              <div style="display: flex; justify-content: space-between; font-size: 12px;">
                <span>Subtotal:</span>
                <span>${receipt.currency}${subtotal.toFixed(2)}</span>
              </div>
              <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 4px;">
                <span>Tax:</span>
                <span>${receipt.currency}${totalTax.toFixed(2)}</span>
              </div>
              <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 4px;">
                <span>Shipping:</span>
                <span>${receipt.currency}${receipt.shipping.toFixed(2)}</span>
              </div>
              ${receipt.discount > 0 ? `
                <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 4px;">
                  <span>Discount:</span>
                  <span>-${receipt.currency}${receipt.discount.toFixed(2)}</span>
                </div>
              ` : ''}
              <div style="display: flex; justify-content: space-between; font-size: 16px; font-weight: bold; margin-top: 8px; padding-top: 8px; border-top: 1px solid #d1d5db;">
                <span>TOTAL:</span>
                <span>${receipt.currency}${grandTotal.toFixed(2)}</span>
              </div>
            </div>
            
            <!-- Payment -->
            <div style="text-align: center; font-size: 12px; margin-bottom: 12px;">
              <p style="margin: 0;">Payment: ${receipt.payment.method.toUpperCase()}</p>
              <p style="margin: 4px 0 0;">Status: ${receipt.payment.status.toUpperCase()}</p>
            </div>
            
            <!-- Footer -->
            <div style="text-align: center; border-top: 1px dashed #9ca3af; padding-top: 12px;">
              <p style="font-size: 12px; color: #4b5563; margin: 0 0 8px;">${receipt.notes || 'Thank you for shopping!'}</p>
              <p style="font-size: 12px; margin: 0;">********************************</p>
              <p style="font-size: 12px; font-weight: bold; margin: 8px 0 0;">CUSTOMER COPY</p>
            </div>
          </div>
        `;
      }
      
      // Append to body
      document.body.appendChild(printContainer);
      
      // Wait for fonts and images to load
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Wait for images to fully load
      const images = printContainer.querySelectorAll('img');
      await Promise.all(
        Array.from(images).map(img => {
          if (img.complete && img.naturalHeight !== 0) return Promise.resolve();
          return new Promise<void>((resolve) => {
            img.onload = () => resolve();
            img.onerror = () => resolve();
            setTimeout(() => resolve(), 3000);
          });
        })
      );
      
      // Generate canvas with html2canvas
      const canvas = await html2canvas(printContainer, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        allowTaint: true,
        width: receipt.style === 3 ? 320 : 794,
        windowWidth: receipt.style === 3 ? 320 : 794,
      });
      
      // Remove the container
      document.body.removeChild(printContainer);
      
      // Create PDF
      const imgData = canvas.toDataURL('image/png', 1.0);
      const isThermal = receipt.style === 3;
      const pdfWidth = isThermal ? 80 : 210;
      const pdfHeight = isThermal ? (canvas.height * 80) / canvas.width : 297;
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: isThermal ? [pdfWidth, Math.max(pdfHeight, 200)] : 'a4',
      });
      
      const actualPdfWidth = pdf.internal.pageSize.getWidth();
      const actualPdfHeight = (canvas.height * actualPdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, actualPdfWidth, actualPdfHeight);
      pdf.save(`${receipt.invoice.prefix}${receipt.invoice.orderId}.pdf`);
      
    } catch (error) {
      console.error('PDF generation error:', error);
      alert('Error generating PDF. Please try again.');
    }
    
    setIsGenerating(false);
  };

  const printReceipt = () => {
    window.print();
  };

  const deleteItem = (type: 'receipt' | 'draft' | 'template', id: string) => {
    if (!confirm('Are you sure you want to delete this item?')) return;
    
    if (type === 'receipt') {
      storage.deleteReceipt(id);
      setReceipts(storage.getReceipts());
    } else if (type === 'draft') {
      storage.deleteDraft(id);
      setDrafts(storage.getDrafts());
    } else {
      storage.deleteTemplate(id);
      setTemplates(storage.getTemplates());
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" style={{ fontFamily: "'Poppins', 'Hind Siliguri', sans-serif" }}>
      {/* Mobile Header */}
      <header className="lg:hidden bg-white shadow-sm sticky top-0 z-40">
        <div className="flex items-center justify-between px-4 py-3">
          <button onClick={() => setSidebarOpen(true)} className="p-2 hover:bg-gray-100 rounded-lg">
            <Menu className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-lg font-bold text-indigo-600">InvoicePro</h1>
          <button 
            onClick={() => setShowPreview(true)}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <FileText className="w-6 h-6 text-gray-600" />
          </button>
        </div>
      </header>

      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed top-0 left-0 h-full w-72 bg-white shadow-xl z-50 transform transition-transform duration-300 lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
                <ReceiptIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-gray-800">InvoicePro</h1>
                <p className="text-xs text-gray-500">Receipt Generator</p>
              </div>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 hover:bg-gray-100 rounded-lg">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          <button
            onClick={() => { setActiveTab('create'); setSidebarOpen(false); }}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
              activeTab === 'create' ? "bg-indigo-50 text-indigo-600" : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <Plus className="w-5 h-5" />
            <span className="font-medium">Create New</span>
          </button>
          <button
            onClick={() => { setActiveTab('history'); setSidebarOpen(false); }}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
              activeTab === 'history' ? "bg-indigo-50 text-indigo-600" : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <History className="w-5 h-5" />
            <span className="font-medium">History & Drafts</span>
            {(receipts.length + drafts.length) > 0 && (
              <span className="ml-auto bg-gray-200 text-gray-600 text-xs px-2 py-0.5 rounded-full">
                {receipts.length + drafts.length}
              </span>
            )}
          </button>
          <button
            onClick={() => { setActiveTab('templates'); setSidebarOpen(false); }}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
              activeTab === 'templates' ? "bg-indigo-50 text-indigo-600" : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <Bookmark className="w-5 h-5" />
            <span className="font-medium">Templates</span>
            {templates.length > 0 && (
              <span className="ml-auto bg-gray-200 text-gray-600 text-xs px-2 py-0.5 rounded-full">
                {templates.length}
              </span>
            )}
          </button>
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-gray-50">
          <div className="text-xs text-gray-500 text-center">
            <p>Works 100% Offline</p>
            <p className="mt-1">Data stored locally</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-72">
        <div className="max-w-7xl mx-auto p-4 lg:p-8">
          {activeTab === 'create' && (
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Form Section */}
              <div className="space-y-6">
                {/* Style Selector */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <Layout className="w-5 h-5 text-indigo-600" />
                    Receipt Style
                  </h2>
                  <div className="grid grid-cols-3 gap-3">
                    {[1, 2, 3].map((style) => (
                      <button
                        key={style}
                        onClick={() => setReceipt(prev => ({ ...prev, style: style as ReceiptStyle }))}
                        className={cn(
                          "p-4 rounded-xl border-2 transition-all",
                          receipt.style === style
                            ? "border-indigo-600 bg-indigo-50"
                            : "border-gray-200 hover:border-gray-300"
                        )}
                      >
                        {style === 1 && <FileText className="w-6 h-6 mx-auto mb-2 text-gray-600" />}
                        {style === 2 && <LayoutGrid className="w-6 h-6 mx-auto mb-2 text-gray-600" />}
                        {style === 3 && <ReceiptIcon className="w-6 h-6 mx-auto mb-2 text-gray-600" />}
                        <p className="text-xs font-medium text-gray-600">
                          {style === 1 && 'Classic'}
                          {style === 2 && 'Modern'}
                          {style === 3 && 'Thermal'}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Business Info */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-indigo-600" />
                    Business Information
                  </h2>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        {receipt.business.logo ? (
                          <img src={receipt.business.logo} alt="Logo" className="w-20 h-20 object-contain rounded-xl border" />
                        ) : (
                          <div className="w-20 h-20 bg-gray-100 rounded-xl flex items-center justify-center border-2 border-dashed border-gray-300">
                            <Image className="w-8 h-8 text-gray-400" />
                          </div>
                        )}
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoUpload}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-500 mb-1">Upload Logo</p>
                        <p className="text-xs text-gray-400">PNG, JPG up to 2MB</p>
                      </div>
                    </div>
                    <input
                      type="text"
                      placeholder="Business Name"
                      value={receipt.business.name}
                      onChange={e => setReceipt(prev => ({ ...prev, business: { ...prev.business, name: e.target.value } }))}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="email"
                        placeholder="Email"
                        value={receipt.business.email}
                        onChange={e => setReceipt(prev => ({ ...prev, business: { ...prev.business, email: e.target.value } }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                      <input
                        type="tel"
                        placeholder="Phone"
                        value={receipt.business.phone}
                        onChange={e => setReceipt(prev => ({ ...prev, business: { ...prev.business, phone: e.target.value } }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Address (Optional)"
                      value={receipt.business.address}
                      onChange={e => setReceipt(prev => ({ ...prev, business: { ...prev.business, address: e.target.value } }))}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                    />
                  </div>
                </div>

                {/* Invoice Info */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-indigo-600" />
                    Invoice Information
                  </h2>
                  <div className="space-y-4">
                    <input
                      type="text"
                      placeholder="Invoice Title (e.g., INVOICE, RECEIPT)"
                      value={receipt.invoice.title}
                      onChange={e => setReceipt(prev => ({ ...prev, invoice: { ...prev.invoice, title: e.target.value } }))}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="Prefix (e.g., INV-)"
                        value={receipt.invoice.prefix}
                        onChange={e => setReceipt(prev => ({ ...prev, invoice: { ...prev.invoice, prefix: e.target.value } }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                      <input
                        type="text"
                        placeholder="Order ID"
                        value={receipt.invoice.orderId}
                        onChange={e => setReceipt(prev => ({ ...prev, invoice: { ...prev.invoice, orderId: e.target.value } }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        placeholder="Date"
                        value={receipt.invoice.orderDate}
                        onChange={e => setReceipt(prev => ({ ...prev, invoice: { ...prev.invoice, orderDate: e.target.value } }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                      <input
                        type="text"
                        placeholder="Currency Symbol"
                        value={receipt.currency}
                        onChange={e => setReceipt(prev => ({ ...prev, currency: e.target.value }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Customer Info */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <User className="w-5 h-5 text-indigo-600" />
                    Customer Information
                  </h2>
                  <div className="space-y-4">
                    <input
                      type="text"
                      placeholder="Customer Name"
                      value={receipt.customer.name}
                      onChange={e => setReceipt(prev => ({ ...prev, customer: { ...prev.customer, name: e.target.value } }))}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="email"
                        placeholder="Email"
                        value={receipt.customer.email}
                        onChange={e => setReceipt(prev => ({ ...prev, customer: { ...prev.customer, email: e.target.value } }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                      <input
                        type="tel"
                        placeholder="Phone"
                        value={receipt.customer.phone}
                        onChange={e => setReceipt(prev => ({ ...prev, customer: { ...prev.customer, phone: e.target.value } }))}
                        className="px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Address"
                      value={receipt.customer.address}
                      onChange={e => setReceipt(prev => ({ ...prev, customer: { ...prev.customer, address: e.target.value } }))}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                    />
                  </div>
                </div>

                {/* Products */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <Package className="w-5 h-5 text-indigo-600" />
                    Products / Items
                  </h2>
                  <div className="space-y-4">
                    {receipt.products.map((product, index) => (
                      <div key={product.id} className="p-4 bg-gray-50 rounded-xl space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-500">Item {index + 1}</span>
                          {receipt.products.length > 1 && (
                            <button
                              onClick={() => removeProduct(product.id)}
                              className="p-1 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <input
                            type="text"
                            placeholder="Product Name"
                            value={product.name}
                            onChange={e => updateProduct(product.id, 'name', e.target.value)}
                            className="px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                          />
                          <input
                            type="text"
                            placeholder="Variation (Size, Color)"
                            value={product.variation}
                            onChange={e => updateProduct(product.id, 'variation', e.target.value)}
                            className="px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                          />
                        </div>
                        <div className="grid grid-cols-4 gap-3">
                          <select
                            value={product.deliveryType}
                            onChange={e => updateProduct(product.id, 'deliveryType', e.target.value)}
                            className="px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm bg-white"
                          >
                            <option value="standard">Standard</option>
                            <option value="express">Express</option>
                            <option value="pickup">Pickup</option>
                            <option value="digital">Digital</option>
                          </select>
                          <input
                            type="number"
                            placeholder="Qty"
                            min="1"
                            value={product.quantity}
                            onChange={e => updateProduct(product.id, 'quantity', parseInt(e.target.value) || 1)}
                            className="px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                          />
                          <input
                            type="number"
                            placeholder="Price"
                            min="0"
                            step="0.01"
                            value={product.unitPrice || ''}
                            onChange={e => updateProduct(product.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                            className="px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                          />
                          <input
                            type="number"
                            placeholder="Tax %"
                            min="0"
                            value={product.tax || ''}
                            onChange={e => updateProduct(product.id, 'tax', parseFloat(e.target.value) || 0)}
                            className="px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                          />
                        </div>
                        <div className="text-right text-sm font-medium text-indigo-600">
                          Total: {receipt.currency}{(product.quantity * product.unitPrice * (1 + product.tax / 100)).toFixed(2)}
                        </div>
                      </div>
                    ))}
                    <button
                      onClick={addProduct}
                      className="w-full py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-indigo-500 hover:text-indigo-600 transition-colors flex items-center justify-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Add Product
                    </button>
                  </div>
                </div>

                {/* Pricing */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-indigo-600" />
                    Pricing & Payment
                  </h2>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Shipping Cost</label>
                        <input
                          type="number"
                          placeholder="0.00"
                          min="0"
                          step="0.01"
                          value={receipt.shipping || ''}
                          onChange={e => setReceipt(prev => ({ ...prev, shipping: parseFloat(e.target.value) || 0 }))}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Discount</label>
                        <input
                          type="number"
                          placeholder="0.00"
                          min="0"
                          step="0.01"
                          value={receipt.discount || ''}
                          onChange={e => setReceipt(prev => ({ ...prev, discount: parseFloat(e.target.value) || 0 }))}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Payment Method</label>
                        <select
                          value={receipt.payment.method}
                          onChange={e => setReceipt(prev => ({ ...prev, payment: { ...prev.payment, method: e.target.value as PaymentInfo['method'] } }))}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none bg-white"
                        >
                          <option value="cash">Cash</option>
                          <option value="card">Card</option>
                          <option value="bank">Bank Transfer</option>
                          <option value="mobile">Mobile Payment</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-sm text-gray-500 mb-1 block">Payment Status</label>
                        <select
                          value={receipt.payment.status}
                          onChange={e => setReceipt(prev => ({ ...prev, payment: { ...prev.payment, status: e.target.value as PaymentInfo['status'] } }))}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none bg-white"
                        >
                          <option value="pending">Pending</option>
                          <option value="paid">Paid</option>
                          <option value="partial">Partial</option>
                          <option value="overdue">Overdue</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4">
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between text-gray-600">
                          <span>Subtotal</span>
                          <span>{receipt.currency}{calculateSubtotal().toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-gray-600">
                          <span>Tax</span>
                          <span>{receipt.currency}{calculateTotalTax().toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-gray-600">
                          <span>Shipping</span>
                          <span>{receipt.currency}{receipt.shipping.toFixed(2)}</span>
                        </div>
                        {receipt.discount > 0 && (
                          <div className="flex justify-between text-green-600">
                            <span>Discount</span>
                            <span>-{receipt.currency}{receipt.discount.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="flex justify-between pt-2 border-t border-indigo-200 text-lg font-bold text-indigo-700">
                          <span>Grand Total</span>
                          <span>{receipt.currency}{calculateGrandTotal().toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Notes & Signature */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <StickyNote className="w-5 h-5 text-indigo-600" />
                    Notes & Signature
                  </h2>
                  <div className="space-y-4">
                    <textarea
                      placeholder="Notes (visible on receipt)"
                      value={receipt.notes}
                      onChange={e => setReceipt(prev => ({ ...prev, notes: e.target.value }))}
                      rows={2}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none resize-none"
                    />
                    <textarea
                      placeholder="Terms & Conditions"
                      value={receipt.terms}
                      onChange={e => setReceipt(prev => ({ ...prev, terms: e.target.value }))}
                      rows={2}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none resize-none"
                    />
                    <div className="flex items-center gap-4">
                      <div className="relative flex-shrink-0">
                        {receipt.signature ? (
                          <img src={receipt.signature} alt="Signature" className="h-16 object-contain border rounded-lg p-2" />
                        ) : (
                          <div className="w-32 h-16 bg-gray-100 rounded-xl flex items-center justify-center border-2 border-dashed border-gray-300">
                            <FileSignature className="w-6 h-6 text-gray-400" />
                          </div>
                        )}
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleSignatureUpload}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Upload Signature</p>
                        <p className="text-xs text-gray-400">PNG with transparent background</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={saveDraft}
                      className="py-3 px-4 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                    >
                      <Clock className="w-5 h-5" />
                      Save Draft
                    </button>
                    <button
                      onClick={() => setShowTemplateModal(true)}
                      className="py-3 px-4 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                    >
                      <Bookmark className="w-5 h-5" />
                      Save Template
                    </button>
                    <button
                      onClick={saveReceipt}
                      className="py-3 px-4 rounded-xl bg-green-600 text-white hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <Save className="w-5 h-5" />
                      Save Receipt
                    </button>
                    <button
                      onClick={() => setReceipt(createNewReceipt())}
                      className="py-3 px-4 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      New Receipt
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-3">
                    <button
                      onClick={downloadPDF}
                      disabled={isGenerating}
                      className="py-3 px-4 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      <Download className="w-5 h-5" />
                      {isGenerating ? 'Generating...' : 'Download PDF'}
                    </button>
                    <button
                      onClick={printReceipt}
                      className="py-3 px-4 rounded-xl bg-purple-600 text-white hover:bg-purple-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <Printer className="w-5 h-5" />
                      Print
                    </button>
                  </div>
                </div>
              </div>

              {/* Preview Section - Desktop */}
              <div className="hidden lg:block sticky top-8">
                <div className="bg-white rounded-2xl shadow-sm p-4 border border-gray-100">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <FileCheck className="w-5 h-5 text-indigo-600" />
                    Live Preview
                  </h2>
                  <div className="bg-gray-100 rounded-xl p-4 max-h-[calc(100vh-200px)] overflow-auto" id="receipt-preview">
                    <div className="transform scale-[0.6] origin-top">
                      {receipt.style === 1 && <ReceiptStyle1 receipt={receipt} qrCode={qrCode} barcode={barcode} />}
                      {receipt.style === 2 && <ReceiptStyle2 receipt={receipt} qrCode={qrCode} />}
                      {receipt.style === 3 && <ReceiptStyle3 receipt={receipt} />}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800">History & Drafts</h2>
              
              {/* Drafts */}
              <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-yellow-600" />
                  Drafts ({drafts.length})
                </h3>
                {drafts.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No drafts saved yet</p>
                ) : (
                  <div className="space-y-3">
                    {drafts.map(draft => (
                      <div key={draft.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                        <div>
                          <p className="font-medium text-gray-800">{draft.invoice.prefix}{draft.invoice.orderId}</p>
                          <p className="text-sm text-gray-500">{draft.customer.name || 'No customer'} • {draft.invoice.orderDate}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => loadReceipt(draft)}
                            className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => deleteItem('draft', draft.id)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Receipts */}
              <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-green-600" />
                  Saved Receipts ({receipts.length})
                </h3>
                {receipts.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No receipts saved yet</p>
                ) : (
                  <div className="space-y-3">
                    {receipts.map(r => (
                      <div key={r.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                        <div>
                          <p className="font-medium text-gray-800">{r.invoice.prefix}{r.invoice.orderId}</p>
                          <p className="text-sm text-gray-500">
                            {r.customer.name || 'No customer'} • {r.currency}{(r.products.reduce((sum, p) => sum + p.quantity * p.unitPrice * (1 + p.tax/100), 0) + r.shipping - r.discount).toFixed(2)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => loadReceipt(r)}
                            className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                          >
                            <Copy className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => deleteItem('receipt', r.id)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'templates' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800">Templates</h2>
              <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                  <Bookmark className="w-5 h-5 text-purple-600" />
                  Saved Templates ({templates.length})
                </h3>
                {templates.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No templates saved yet. Create a receipt and save it as a template!</p>
                ) : (
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {templates.map(template => (
                      <div key={template.id} className="p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl border border-purple-100">
                        <h4 className="font-semibold text-gray-800 mb-2">{template.templateName}</h4>
                        <p className="text-sm text-gray-500 mb-3">{template.business.name || 'No business name'}</p>
                        <p className="text-xs text-gray-400 mb-4">{template.products.length} items • Style {template.style}</p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => loadReceipt(template)}
                            className="flex-1 py-2 px-3 bg-indigo-600 text-white rounded-lg text-sm hover:bg-indigo-700 transition-colors"
                          >
                            Use Template
                          </button>
                          <button
                            onClick={() => deleteItem('template', template.id)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Mobile Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black/50 z-50 lg:hidden flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-hidden">
            <div className="p-4 border-b flex items-center justify-between">
              <h3 className="font-semibold text-gray-800">Preview</h3>
              <button onClick={() => setShowPreview(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="p-4 overflow-auto max-h-[70vh]" id="receipt-preview">
              <div className="transform scale-[0.45] origin-top">
                {receipt.style === 1 && <ReceiptStyle1 receipt={receipt} qrCode={qrCode} barcode={barcode} />}
                {receipt.style === 2 && <ReceiptStyle2 receipt={receipt} qrCode={qrCode} />}
                {receipt.style === 3 && <ReceiptStyle3 receipt={receipt} />}
              </div>
            </div>
            <div className="p-4 border-t grid grid-cols-2 gap-3">
              <button
                onClick={downloadPDF}
                disabled={isGenerating}
                className="py-3 px-4 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Download className="w-5 h-5" />
                PDF
              </button>
              <button
                onClick={printReceipt}
                className="py-3 px-4 rounded-xl bg-purple-600 text-white hover:bg-purple-700 transition-colors flex items-center justify-center gap-2"
              >
                <Printer className="w-5 h-5" />
                Print
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Template Name Modal */}
      {showTemplateModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Save as Template</h3>
            <input
              type="text"
              placeholder="Template Name"
              value={templateName}
              onChange={e => setTemplateName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none mb-4"
              autoFocus
            />
            <div className="flex gap-3">
              <button
                onClick={() => { setShowTemplateModal(false); setTemplateName(''); }}
                className="flex-1 py-3 px-4 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={saveAsTemplate}
                className="flex-1 py-3 px-4 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition-colors"
              >
                Save Template
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PDF is generated dynamically in downloadPDF function */}
    </div>
  );
}
