import { Receipt } from '../types';

const STORAGE_KEYS = {
  RECEIPTS: 'invoicepro_receipts',
  DRAFTS: 'invoicepro_drafts',
  TEMPLATES: 'invoicepro_templates',
  BUSINESS: 'invoicepro_business',
  SETTINGS: 'invoicepro_settings',
};

export const storage = {
  // Receipts
  getReceipts: (): Receipt[] => {
    const data = localStorage.getItem(STORAGE_KEYS.RECEIPTS);
    return data ? JSON.parse(data) : [];
  },
  
  saveReceipt: (receipt: Receipt): void => {
    const receipts = storage.getReceipts();
    const index = receipts.findIndex(r => r.id === receipt.id);
    if (index >= 0) {
      receipts[index] = receipt;
    } else {
      receipts.unshift(receipt);
    }
    localStorage.setItem(STORAGE_KEYS.RECEIPTS, JSON.stringify(receipts));
  },
  
  deleteReceipt: (id: string): void => {
    const receipts = storage.getReceipts().filter(r => r.id !== id);
    localStorage.setItem(STORAGE_KEYS.RECEIPTS, JSON.stringify(receipts));
  },

  // Drafts
  getDrafts: (): Receipt[] => {
    const data = localStorage.getItem(STORAGE_KEYS.DRAFTS);
    return data ? JSON.parse(data) : [];
  },
  
  saveDraft: (draft: Receipt): void => {
    const drafts = storage.getDrafts();
    const index = drafts.findIndex(d => d.id === draft.id);
    if (index >= 0) {
      drafts[index] = draft;
    } else {
      drafts.unshift(draft);
    }
    localStorage.setItem(STORAGE_KEYS.DRAFTS, JSON.stringify(drafts));
  },
  
  deleteDraft: (id: string): void => {
    const drafts = storage.getDrafts().filter(d => d.id !== id);
    localStorage.setItem(STORAGE_KEYS.DRAFTS, JSON.stringify(drafts));
  },

  // Templates
  getTemplates: (): Receipt[] => {
    const data = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    return data ? JSON.parse(data) : [];
  },
  
  saveTemplate: (template: Receipt): void => {
    const templates = storage.getTemplates();
    const index = templates.findIndex(t => t.id === template.id);
    if (index >= 0) {
      templates[index] = template;
    } else {
      templates.unshift(template);
    }
    localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(templates));
  },
  
  deleteTemplate: (id: string): void => {
    const templates = storage.getTemplates().filter(t => t.id !== id);
    localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(templates));
  },

  // Business Info Cache
  getBusinessInfo: () => {
    const data = localStorage.getItem(STORAGE_KEYS.BUSINESS);
    return data ? JSON.parse(data) : null;
  },
  
  saveBusinessInfo: (business: Receipt['business']): void => {
    localStorage.setItem(STORAGE_KEYS.BUSINESS, JSON.stringify(business));
  },

  // Settings
  getSettings: () => {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return data ? JSON.parse(data) : { currency: '৳', dateFormat: 'DD/MM/YYYY' };
  },
  
  saveSettings: (settings: { currency: string; dateFormat: string }): void => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },
};
