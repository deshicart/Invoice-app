import QRCode from 'qrcode';

export const generateQRCode = async (text: string): Promise<string> => {
  try {
    const qrDataUrl = await QRCode.toDataURL(text, {
      width: 120,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    });
    return qrDataUrl;
  } catch (error) {
    console.error('QR Code generation error:', error);
    return '';
  }
};

export const generateBarcode = (text: string): string => {
  // Simple Code128-like barcode pattern generator
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const barWidth = 2;
  const height = 50;
  const padding = 10;
  
  // Generate simple pattern based on text
  const pattern = text.split('').map(char => {
    const code = char.charCodeAt(0);
    return [
      (code % 2) + 1,
      ((code >> 1) % 2) + 1,
      ((code >> 2) % 2) + 1,
      ((code >> 3) % 2) + 1,
    ];
  }).flat();

  canvas.width = pattern.length * barWidth + padding * 2;
  canvas.height = height + 20;

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  let x = padding;
  pattern.forEach((width, index) => {
    ctx.fillStyle = index % 2 === 0 ? '#000000' : '#ffffff';
    ctx.fillRect(x, 5, width * barWidth, height);
    x += width * barWidth;
  });

  // Add text below
  ctx.fillStyle = '#000000';
  ctx.font = '10px Poppins, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(text, canvas.width / 2, height + 15);

  return canvas.toDataURL();
};
